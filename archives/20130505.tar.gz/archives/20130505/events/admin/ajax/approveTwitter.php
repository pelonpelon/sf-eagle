<?php
include '../common.php';
$twitterObj->approve($_GET["id"]);
?>
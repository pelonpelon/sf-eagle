<?php
include '../common.php';
$calendarObj->setDefaultCalendar($_GET["calendar_id"]);
?>